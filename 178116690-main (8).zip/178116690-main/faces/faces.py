def main():
    n = input("Type Something:")
    print(convert(n))

def convert(n):
    n = n.replace(':(','🙁')
    n = n.replace(':)','🙂')
    return n

main()
