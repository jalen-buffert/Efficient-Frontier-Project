import re

def main():
    print(format_time(parse_time(input("Hours: "))))

def parse_time(s):
        pattern = r"^(\d{1,2}(:(00|[1-5]\d))?)\s(\bAM\b|\bPM\b)\s\bto\b\s(\d{1,2}(:(00|[1-5]\d))?)\s(\bAM\b|\bPM\b)"
        match = re.search(pattern, s)

        if not match:
            raise ValueError
        else:
             return match.group(1),match.group(4),match.group(5), match.group(8)

def format_time(list):
     meridiems = []
     meridiems.append(list[1])
     meridiems.append(list[3])
     times = []
     times.append(list[0])
     times.append(list[2])


     new_time = []
     for item, time in zip(meridiems,times):
        if item == 'AM':
            if len(time)< 3:
                new_time.append(f"{int(time):02}:00")
            else:
                hours, mins = time.split(':')
                h = int(hours)
                new_time.append(f"{h:02}:{mins}")

        if item == "PM":
            try:
                time1 = int(time) + 12
                new_time.append(f"{time1:02}:00")
            except ValueError:
                hours, mins = time.split(':')
                p_h = int(hours) + 12
                new_time.append(f"{p_h:02}:{mins}")


     return f"{new_time[0]} to {new_time[1]}"




if __name__ == "__main__":
    main()
