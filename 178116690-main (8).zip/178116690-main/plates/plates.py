def main():
    plate = input("Plate: ")
    if is_valid(plate):
        print("Valid")
    else:
        print("Invalid")


def is_valid(s):
    return two_letters(s, 2) and valid_length(s) and end_nums(s, 2) and no_punctuation(s, 2)


def two_letters(phrase, end):
    segment = phrase[:end]
    return segment.isalpha()


def valid_length(phrase):
    length = len(phrase)
    return 2 <= length <= 6


def end_nums(phrase, start):

    sub_p = phrase[start:]

    if sub_p.find('0') == 0:
        return False

    index = 0

    if sub_p.isalpha():
        return True

    for x in sub_p:
        if x.isnumeric():
            index = sub_p.index(x)
            break

    for x in sub_p[index:]:
        if not x.isnumeric():
            return False

    return True


def no_punctuation(phrase, start):
    t = phrase[start:]

    return t.isalnum()


main()
