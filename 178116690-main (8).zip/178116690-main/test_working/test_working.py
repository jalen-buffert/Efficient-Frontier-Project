import pytest

from working import convert

def test_single_num():
    assert convert('9 AM to 5 PM') == '09:00 to 17:00'
def test_full_num():
    assert convert('9:00 AM to 5:00 PM') == '09:00 to 17:00'
def test_switch_num():
    assert convert('10 AM to 8:50 PM') == '10:00 to 20:50'
def test_switch_nums():
    assert convert('10:30 PM to 8 AM') == '22:30 to 08:00'
def test_no_meri():
    with pytest.raises(ValueError):
        convert('09:00 AM - 17:00 PM')
def test_bad_struct():
    with pytest.raises(ValueError):
        convert('9 AM - 5 PM')
def test_too_l():
    with pytest.raises(ValueError):
        convert('9:60 AM to 5:60 PM')
def test_too_h():
    with pytest.raises(ValueError):
        convert('13:00 AM - 5:00 PM')
def test_too_m():
    with pytest.raises(ValueError):
        convert('13 AM - 4 PM')
def test_too_0():
    with pytest.raises(ValueError):
        convert('0 PM - 4 PM')
def test_too_pm():
    with pytest.raises(ValueError):
        convert('2 PM - 46:00 PM')













