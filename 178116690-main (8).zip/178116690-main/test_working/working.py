import re

def main():

  print(convert(input("Hours: ")))


def convert(s):
    pattern = re.compile(r"""
                         ^([1-9]|1[0-2])
                         :?([0-5][0-9])?
                         \s(AM|PM)\s
                         to\s
                         ([1-9]|1[0-2])
                         :?([0-5][0-9])?
                         \s(AM|PM)
                         """, re.VERBOSE)
    if matches := re.search(pattern, s):
       t1,m1,me1,t2,m2,me2 = matches.groups()
    else:
        raise ValueError

    if m1 == None:
       m1 = '00'
    if m2 == None:
       m2 = '00'

    def con_hour(time, mins, meri):
       t = int(time)
       if meri == 'AM':
          if t == 12:
             t = 0
       else:
          if not t == 12:
             t += 12
       return f'{t:02}:{mins}'

    beg = con_hour(t1,m1,me1)
    end = con_hour(t2,m2,me2)

    return f"{beg} to {end}"


if __name__ == "__main__":
    main()
