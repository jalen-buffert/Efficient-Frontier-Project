import random

random.seed(0)

def main():
    level = get_level()

    list = get_equations(level, num_equations=10)

    return solve(list)



def get_level():

    while True:
        l = input("Level: ")


        match l:
            case "1" | "2" | "3":
                new_l = int(l)
                break
            case _:
                pass
    return new_l



def generate_integer(level):
    if level == 1:
        min = (10**(level - 1))-1
    else:
        min = 10**(level - 1)
    max = 10**(level) -1
    return random.randint(min , max)

def get_equations(level, num_equations=10):
    i = 0

    equations = []

    while i < num_equations:
        x, y = generate_integer(level), generate_integer(level)
        answer = x + y
        eq = f'{x} + {y} '
        equations.append([eq, answer])

        i+=1
    return equations


def solve(equations):

    correct = 0
    for equation in equations:

        attempts = 3
        e1 = equation[0] +  "="
        while True:
            ans = input(e1)
            if not ans.isnumeric():
                print("EEE")
                attempts -= 1
                continue
            else:
                ans1 = int(ans)

            if ans1 == equation[1]:
                correct+=1
                break
            else:
                print("EEE")
                attempts -= 1
                pass

            if attempts == 0:
                print(f"{equation[0]} = {equation[1]}")
                break
    print(correct)








if __name__ == "__main__":
    main()
