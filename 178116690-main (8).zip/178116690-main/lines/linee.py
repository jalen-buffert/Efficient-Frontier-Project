# The main

def main():
    hello = 2 + 1
    world = 3 + 4
    case = hello + world
    return case


# the end
