import sys

def main():
    code = get_lines()
    print(count_lines(code))

def get_lines():
    args = len(sys.argv)
    if args > 2:
        sys.exit('Too many command-line arguments')
    elif args < 2:
        sys.exit('Too few command-line arguments')
    else:
        pass

    file_o = sys.argv[1]

    if not file_o.endswith('.py'):
        sys.exit('Not a Python File')

    lines = []
    try:
        with open(file_o) as file:
            for line in file:
                line = line.strip()
                if line == '' or line.startswith('#'):
                    continue
                else:
                    lines.append(line)
            return lines
    except FileNotFoundError:
        sys.exit('File does not exist')

def count_lines(list1):
    count = 0
    for item in list1:
        count += 1
    return count



if __name__ == "__main__":
    main()

