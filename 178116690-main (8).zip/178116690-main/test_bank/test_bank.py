import pytest

from bank import value

def test_hello_mix():
    assert value('hEllo') == 0

def test_upper():
    assert value('HELLO') == 0
def test_lower():
    assert value('hello') == 0
def test_hello_plus():
    assert value('hello Jalen') == 0
def test_h():
    assert value('heyy') == 20
def test_greet():
    assert value('Good morning') == 100
def test_num():
    assert value('Good 1ornin3') == 100
def test_spec_char():
    assert value('Aftern$$n Budd%') == 100
