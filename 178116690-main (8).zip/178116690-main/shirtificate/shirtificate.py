from fpdf import FPDF,Align

class Shirt:
    def __init__(self,name):
        self.name = name
        self.shirt = Shirt.text_to_shirt(self.name)
        return self.shirt

    @classmethod
    def text_to_shirt(cls, name):
        pdf = FPDF(orientation='P', format ='A4')
        pdf.set_margin(0)
        pdf.add_page()
        pdf.set_font('helvetica', style='B', size=35)
        pdf.cell(w=210, h=55, text='CS50 Shirtificate',align='C')
        pdf.image('shirtificate.png',w=pdf.epw*.90,y=65,x=Align.C)
        pdf.set_text_color(255, 255, 255)
        pdf.set_y(115)
        pdf.set_font('helvetica', size=35)
        pdf.cell(w=210, text=name, align='C')
        return pdf.output('shirtificate.pdf')


    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, name):
        self._name = name

def main():
    print(Shirt(input("Name: ")))


if __name__ == '__main__':
    main()
