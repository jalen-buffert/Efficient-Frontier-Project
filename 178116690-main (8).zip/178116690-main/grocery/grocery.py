def main():
    g_l = {}
    i = 1

    while True:
        try:
            n = input()
        except EOFError:
            break

        g_l[i] = n
        i +=1
    #print(g_list)

    return grocery(g_l)

def grocery(l):
    new_dict ={}

    for value in l.values():

        if value not in new_dict:
            new_dict[value] = (1, value.upper())
        else:
            new_dict[value] = (new_dict[value][0] + 1, value.upper())

    fin_dict = sorted(new_dict, reverse=False)

    for i in fin_dict:
        print(f"{new_dict[i][0]} {i.upper()}")

main()
