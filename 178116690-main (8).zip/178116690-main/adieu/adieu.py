import inflect

def main():

    names = []

    while True:
        try:
            n = input()
            names.append(n)
        except EOFError:
            break

    print(goodbye(names))


def goodbye(name_list):
    p = inflect.engine()
    k = p.join(name_list)
    return f"Adieu, adieu, to {k}"

main()
