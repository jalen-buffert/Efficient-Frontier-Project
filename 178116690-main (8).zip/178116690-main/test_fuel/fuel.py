def main():
    while True:
        try:
            fract = input("Fraction: ")
            p = convert(fract)
            print(gauge(p))
            break

        except (ValueError, ZeroDivisionError):
            pass

def convert(fraction):

    x, y = fraction.split("/")


    if not x.isnumeric() or not y.isnumeric():
        raise ValueError

    x = int(x)
    y = int(y)

    if y == 0:
        raise ZeroDivisionError
    if x > y:
        raise ValueError

    num = x/y

    pct = round(num*100)
    return pct




def gauge(percent):
    if 0 <= percent <= 1 :
        return 'E'
    elif 100 >= percent >= 99:
        return 'F'
    elif percent > 100 or percent < 0:
        raise ValueError
    else:
        return f"{percent}%"


if __name__ == "__main__":
    main()
