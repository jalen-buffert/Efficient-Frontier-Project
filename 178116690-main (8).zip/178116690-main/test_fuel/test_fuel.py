import pytest

from fuel import convert
from fuel import gauge


def test_fract():
    assert convert('1/4') == 25
    assert convert('3/4') == 75

def test_numericerror():
    with pytest.raises(ValueError):
        convert('b/3')
        convert('3/j')
def test_negfraction():
    with pytest.raises(ValueError):
        convert('-3/4')
        convert('-2/3')
def test_zeroerror():
    with pytest.raises(ZeroDivisionError):
        convert('3/0')
        convert('0//0')

def test_E():
    assert gauge(1) == 'E'
def test_format():
    assert gauge(35) == '35%'
def test_F():
    assert gauge(99) == 'F'







