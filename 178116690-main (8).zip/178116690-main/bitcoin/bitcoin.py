import requests
import sys

def main():

    s = get_num()
    p = get_bitcoin_price()

    print(f'${cost(s,p):,.4f}')


def get_num():
    if len(sys.argv) == 1:
        sys.exit("Missing command-line argument")
    try:
        num = float(sys.argv[1])
    except:
        sys.exit("Command-line argument is not a number")

    return num

def get_bitcoin_price():
    try:
        response = requests.get("https://rest.coincap.io/v3/assets/bitcoin?apiKey=2d9f7a85f3c438a4fdccc67be9cc4d9de7c6edd42fece4a40263c0256fcd5e15")
        response.raise_for_status()
    except requests.RequestException:
        print("Couldn't complete request")
        return

    c = response.json()

    return float(c['data']['priceUsd'])

def cost(shares, price):
    return shares * price


main()
