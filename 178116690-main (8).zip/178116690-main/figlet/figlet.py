import sys
import random
from pyfiglet import Figlet

figlet = Figlet()
f = figlet.getFonts()



def main():

    user_f = validate_arg()

    n = input("Input: ")

    if user_f == True:
        return user_font(n)
    else:
        return random_font(n)

def validate_arg():

        if len(sys.argv) == 3:
            font = sys.argv[1]
            user_f = sys.argv[2]

            match font:
                case '-f' | '--font':
                    pass
                case _:
                    sys.exit('Invalid Usage')

            if user_f in f:
                return True
            else:
                sys.exit('Invalid Usage')

        elif len(sys.argv) == 1:
            return False

        else:
            sys.exit('Invalid Usage')


def random_font(txt):
    figlet.setFont(font=random.choice(f))
    print(figlet.renderText(txt))

def user_font(txt):

    figlet.setFont(font=sys.argv[2])
    print(figlet.renderText(txt))


main()
