import pytest

from seasons import convert,turn_date,date_diff,remove_and
from datetime import date




def test_goodstr():
    assert convert("2024-12-16") == "2024-12-16"

def test_todate():
    assert turn_date("2024-12-16") == date(2024,12,16)

def test_tostr():
    assert date_diff(date(2024,12,17)) == 'five hundred and twenty-five thousand, six hundred'

def test_remove():
    assert remove_and('five hundred and twenty-five thousand, six hundred') == "Five hundred twenty-five thousand, six hundred minutes"


