from datetime import date,timedelta
import sys
import re
import inflect

def main():
    print(remove_and(date_diff(turn_date(convert(input("Date of Birth: "))))))


def convert(d):
    if match := re.fullmatch(r"^((?:1[0-9][0-9][0-9]|20[0-2][0-9])-(?:0[1-9]|1[0-2])-(?:0[1-9]|[1-2][0-9]|3[0-1]))$",d):
        return match.group(1)
    else:
        sys.exit("Invalid Date")

def turn_date(stringd):
    yyyy, mm, dd = stringd.split('-')
    year = int(yyyy)
    month = int(mm)
    day = int(dd)
    try:
        fdate = date(year,month,day)
        return fdate
    except ValueError:
        sys.exit("Invalid Date")

def date_diff(date1):
    today = date.today()
    time = today - date1
    ts = timedelta.total_seconds(time)/60

    t = str(ts)
    components = t.split(' ')

    p = inflect.engine()
    dec = components[0].find(".")
    return p.number_to_words(components[0][:dec])

def remove_and(phrase):
    match = re.sub(r"\band\b",'', phrase, count=0, flags=re.IGNORECASE)
    m1 = match.replace('  ', ' ')
    return f'{m1.capitalize()} minutes'




if __name__ == "__main__":
    main()
