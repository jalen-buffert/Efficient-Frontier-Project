def main():
    n = input("Input: ")
    print(shorten(n))

def shorten(string):
    word = ""
    for l in string:
        match l:
            case 'a' | 'e' | 'i' | 'o' | 'u' :
                word += ""
            case 'A' | 'E' | 'I' | 'O' | 'U':
                word += ""
            case _:
                word += l
    return word

if __name__ == "__main__":
    main()
