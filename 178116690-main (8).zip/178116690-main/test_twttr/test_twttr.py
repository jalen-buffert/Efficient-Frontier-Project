import pytest

from twttr import shorten

def test_upper():
    assert shorten('JALEN') == 'JLN'

def test_lower():
    assert shorten('jalen') == 'jln'
def test_mix():
    assert shorten('JaleN') == 'JlN'

def test_spec_char():
    assert shorten('J$$en') == 'J$$n'
    assert shorten('JAl!n ???') == 'Jl!n ???'
def test_nums():
    assert shorten('Jal3n') == 'Jl3n'














