import re

def main():
    print(validate(input("IPv4 Address: ").strip()))


def validate(ip):
    pattern = r"([1-9]\d?|1\d\d|2[0-4]\d|25[0-5]|0)\.([1-9]\d?|1\d\d|2[0-4]\d|25[0-5]|0)\.([1-9]\d?|1\d\d|2[0-4]\d|25[0-5]|0)\.([1-9]\d?|1\d\d|2[0-4]\d|25[0-5]|0)"

    match = re.fullmatch(pattern, ip)

    if match is None:
        return False

    return True


if __name__ == "__main__":
    main()
