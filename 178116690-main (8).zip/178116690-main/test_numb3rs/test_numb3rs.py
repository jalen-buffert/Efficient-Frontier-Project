import pytest

from numb3rs import validate

def test_too_sm():
    assert validate('-1.4.4.2') == False

def test_too_l():
    assert validate('567.87.456.1000') == False

def test_sm():
    assert validate('0.0.0.0') == True

def test_l():
    assert validate('255.255.255.255') == True
def test_reg():
    assert validate('56.187.99.92') == True

def test_letters():
    assert validate('catt') == False

def test_range():
    assert validate('67.667.878.8888') == False

def test_zeros():
    assert validate('01.02.03.04') == False

def test_dec():
    assert validate('4.2.45.222.34') == False

def test_three():
    assert validate('142.133.11') == False
def test_five():
    assert validate('111.234.33.23.56') == False

def test_num():
    assert validate('45') == False
def test_period():
    assert validate('.') == False 

