print(type(50))
