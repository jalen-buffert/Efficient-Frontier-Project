def main():

    n = input("What time is it?")
    t = convert(n)

    if 7.00 <= t <= 8.00:
        print('breakfast time')
    elif 12.00 <= t <= 13.00:
        print('lunch time')
    elif 18.00 <= t <= 19.00:
        print('dinner time')

def convert(time):

    hours, minutes = time.split(":")
    hours = float(hours)
    minutes = float(minutes)

    minutes = minutes/60
    sum  = hours + minutes
    return sum

if __name__ == "__main__":
    main()
