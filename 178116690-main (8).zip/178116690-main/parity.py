def main():
    x = int(input("What's x?"))

    # assume there is a function
    if is_even(x):
        print('Even')
    else:
        print('Odd')

def is_even(n):
    return (n %2 == 0)
    #return True if n % 2 == 0 else False

main()

