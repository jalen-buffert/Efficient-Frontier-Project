import pytest

from plates import is_valid

def test_twoletters():
    assert is_valid('hherfr') == True
def test_no_twoletters():
    assert is_valid('h1errf') == False
def test_length_l():
    assert is_valid('fjdcecevr') == False
def test_length_s():
    assert is_valid('df3') == True
    assert is_valid('dfh11') == True
def test_num_use():
    assert is_valid('fj45jg') == False
def test_begin_num():
    assert is_valid('45ghf') == False
def test_allnums():
    assert is_valid('45') == False
def test_corr_num_use():
    assert is_valid('ffef34') == True
def test_zero():
    assert is_valid('fgh053') == False
def test_corr_zero():
    assert is_valid('fff300') == True
def test_special_chars():
    assert is_valid('efg.78') == False
    assert is_valid('efbt@') == False

