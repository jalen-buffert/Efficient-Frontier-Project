n = input("camelCase:")

t = ""
for s in n:
    if s.isupper() == True:
        t += "_"
    t += s.lower()

print("snake_case: " + t)
