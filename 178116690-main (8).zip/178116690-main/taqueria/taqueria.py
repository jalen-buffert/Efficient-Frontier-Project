dict = {
    "Baja Taco": 4.25,
    "Burrito": 7.50,
    "Bowl": 8.50,
    "Nachos": 11.00,
    "Quesadilla": 8.50,
    "Super Burrito": 8.50,
    "Super Quesadilla": 9.50,
    "Taco": 3.00,
    "Tortilla Salad": 8.00
}

def main():
    return order()

def order():

    total = 0

    while True:
        try:
            n = input("Item: ")
            n = n.title()

            if n in dict:
                price = float(dict.get(n))
                price = round(price, ndigits = 3)
                total += price
                print(f"Total: ${total:.2f}")
        except KeyError:
            pass
        except EOFError:
            print("\n")
            break
        except:
            pass

main()
