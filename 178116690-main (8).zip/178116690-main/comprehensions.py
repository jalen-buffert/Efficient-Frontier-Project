def main():
    words = get_words("address.txt")
    # list comprehension
    lowercase_words = [ word.lower() for word in words]

    counts = {word: words.count(word) for word in lowercase_words}

    save_counts(counts)

main()
