import re

def main():
    print(count(input("Text: ")))


def count(s):
    if matches := re.findall(r"\bum\b",s, re.IGNORECASE):
        c = 0
        for match in matches:
             if 'um' in match.lower():
                 c += 1
        return c

if __name__ == "__main__":
    main()
