import pytest

from um import count


def test_single():
    assert count('um') == 1
def test_umspec():
    assert count('um?') == 1
def test_umUpper():
    assert count('I hope work was Um work today.') == 1
def test_multiUm():
    assert count('So um wat, would you Um..') == 2
def test_inword():
    assert count('Um? Mum? Is this that album where, um, umm, the clumsy alums play drums?') == 2

