def main():
    x = int(input("What's x? "))
    print("x squared is", square(x))

def square(n):
    #squaring #'s
    return pow(n,2)
    #return n*n

if __name__ == "__main__":
    main()
