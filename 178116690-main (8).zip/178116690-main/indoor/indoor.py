n = input('Type something:')

print(n.lower())
