import emoji

def main():
    n = input("Input: ")
    print(transform(n))



def transform(e):
    try:
        output = emoji.emojize(e, language='alias')
        return f"Output: {output}"
    except ValueError:
        print('Invalid')
        return

main()
