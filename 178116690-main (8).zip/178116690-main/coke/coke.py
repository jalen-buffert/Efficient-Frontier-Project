due = 50

while due > 0:
    print(f"Amount due: {due}")
    n = int(input("Insert Coin: "))

    if n == 25:
        due -= 25
    elif n == 10:
        due -= 10
    elif n == 5:
        due -= 5

change = due*(-1)
print(f"Change Owed: {change}")



