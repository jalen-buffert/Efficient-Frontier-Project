import sys

from PIL import Image, ImageOps

overlay_img = 'shirt.png'

def main():

    valid_args()
    valid_ext()
    overlay(overlay_img)

def valid_args():
    args = len(sys.argv)

    if args > 3:
        sys.exit("Too many command-line arguments")
    elif args < 3:
        sys.exit("Too few command-line arguments")
    else:
        pass

def valid_ext():
    extensions = []
    for arg in sys.argv[1:]:
        if not arg.endswith('.png') and not arg.endswith('.jpeg') and not arg.endswith('.jpg'):
            sys.exit("Incorrect file type")

        start = arg.find('.')
        ext = arg[start:]
        extensions.append(ext)

    if not extensions[0] == extensions[1]:
        sys.exit('Input and output have different extensions')

def overlay(file):

    try:
        with Image.open(sys.argv[1]) as img, Image.open(file) as file1:
            size = file1.size
            img_fit = ImageOps.fit(img, size)
            img_fit.paste(file1, file1)
            img_fit.save(sys.argv[2])

    except FileNotFoundError:
        sys.exit('Input does not exist')


if __name__ == "__main__":
    main()

