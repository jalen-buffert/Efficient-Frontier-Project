import random

cards = ["jack", "queen", "king"]

def main():

    random.seed(1)
    #with replacements
    print(random.choices(cards, weights=[75,20,5], k=2))
    #without replacements
    #print(random.sample(cards, k=2))



main()
