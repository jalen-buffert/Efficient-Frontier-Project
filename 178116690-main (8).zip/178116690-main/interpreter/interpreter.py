n = input('Expression:')
n = n.strip()
x, y, z = n.split(" ")
x = float(x)
z = float(z)

match y:
    case "+":
        print(x+z)
    case "-":
        print(x-z)
    case "*":
        print(x*z)
    case "/":
        print(x/z)

