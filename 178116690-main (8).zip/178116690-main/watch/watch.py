import re

def main():
    print(parse(input("HTML: ")))


def parse(s):
    pattern = r'^<\biframe\b[\w\s\W]+"(http)s?(://)(www\.)?(youtube)\.com/embed(/\w+)"'

    match = re.search(pattern, s)

    if not match:
        return None
    else:
        return f"{match.group(1)}s{match.group(2)}youtu.be{match.group(5)}"




if __name__ == "__main__":
    main()
