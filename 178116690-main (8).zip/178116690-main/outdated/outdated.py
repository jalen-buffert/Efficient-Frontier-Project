months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
]

def main():

    while True:
        try:
            n = input("Date: ").strip()
            return convert(n)
        except ValueError:
            pass



def extr_if_num(date):
    if date[:1].isnumeric():
        new_d = date.split('/')

        mm = int(new_d[0])
        dd = int(new_d[1])
        yyyy = int(new_d[2])

        return mm, dd, yyyy
    else:
        raise ValueError


def extr_if_alpha(date):
    if date[:1].isalpha():
        x = date.find(' ')
        new_m = date[:x]
        for month in months:
            if new_m == month:
                mm = months.index(month) + 1

        y = date.find(',')
        dd = int(date[x+1:y])
        yyyy = int(date[y+1:])

        return mm, dd, yyyy
    else:
        raise ValueError


def convert(date):

    if date[:1].isnumeric():
        mm_1, dd_1, yyyy = extr_if_num(date)
    elif date[:1].isalpha():
        mm_1, dd_1, yyyy = extr_if_alpha(date)

    if  0 < mm_1 <= 12 and 0 < dd_1 <= 31:
        mm,dd = mm_1, dd_1
    else:
        raise ValueError

    print(f"{yyyy}-{mm:02}-{dd:02}")


main()

