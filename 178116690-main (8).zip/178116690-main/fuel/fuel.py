def main():
    print(convert())

def convert():

    while True:

        string = input("Fraction: ")

        try:
            x, y = string.split("/")

            x = int(x)
            y = int(y)

            if x > y:
                raise ValueError

            num = x/y
            pct = round(num*100)

            if 0 <= pct <= 1 :
                return 'E'
            elif 100 >= pct >= 99:
                return 'F'
            elif pct > 100 or pct < 0:
                raise ValueError

            return f"{pct}%"

        except (ValueError, ZeroDivisionError):
            pass

main()










