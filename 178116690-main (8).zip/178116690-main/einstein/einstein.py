n = int(input("Ma:"))
e = pow(300000000,2)
s = n*e
print('E:', s)
