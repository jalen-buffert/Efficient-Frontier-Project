import random
import sys

invalid = 0

def main():

    level = start('Level')
    magic_num = random_num(level)

    while True:
        guess = start('Guess')

        if check2(guess, magic_num):
            sys.exit("Just right!")
        else:
            pass

def start(prompt):
    while True:
        k = input(prompt + ": ")
        new_k = check(k)
        if new_k > 0:
            break
        else:
            pass
    return new_k

def check(value):
    if value.isnumeric() == False:
        return invalid

    return int(value)

def random_num(bound):
    return random.randint(1,bound)


def check2(guess,answer):

    if guess < answer:
        print("Too small!")
        return False

    elif guess > answer:
        print("Too large!")
        return False
    else:
        return True



main()

