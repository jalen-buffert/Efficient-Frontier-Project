import sys
from tabulate import tabulate
import csv

format = 'grid'

def main():

    f = validate_arg()
    print(gen_table(f))

def validate_arg():
    arg = len(sys.argv)

    if arg > 2:
        sys.exit("Too many command-line arguments")
    elif arg < 2:
        sys.exit("Too few command-line arguments")
    else:
        pass

    file = sys.argv[1]

    if not file.endswith('.csv'):
        sys.exit('Not a CSV file')

    return file

def gen_table(file1):
    menu = []
    try:
        with open(file1) as file:
            reader = csv.reader(file)
            for row in reader:
                menu.append(row)

        return tabulate(menu[1:], headers= menu[0], tablefmt = format)

    except FileNotFoundError:
        sys.exit('File does not exist')

if __name__ == "__main__":
    main()
