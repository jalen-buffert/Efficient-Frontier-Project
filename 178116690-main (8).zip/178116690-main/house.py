# Match cases
name = input("What is your name?")

match name:
    case 'Joe' | 'Bob' | 'Octopus':
        print('Dumb')
    case 'Jalen':
        print('Gryyfff')
    case _:
        print('Huffl')
