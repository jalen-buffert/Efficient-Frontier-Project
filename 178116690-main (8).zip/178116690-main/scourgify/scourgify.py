import sys
import csv

names = ['first', 'last', 'house']
def main():
    files = validate_arg()
    print(sort_files(files))





def validate_arg():
    arg = len(sys.argv)

    if arg < 3:
        sys.exit("Too few command-line arguments")
    elif arg > 3:
        sys.exit("Too many command-line arguments")
    else:
        pass

    return sys.argv[1], sys.argv[2]

def sort_files(files):
    original_file = files[0]
    try:
        with open(original_file) as file, open(files[1], 'w') as sortedl:
            reader = csv.DictReader(file)
            writer = csv.DictWriter(sortedl,fieldnames = names)
            writer.writeheader()
            for row in reader:
                last, first = row['name'].split(',')

                house = row['house'].strip()

                writer.writerow(
                    {
                        "first": first.strip(),
                        "last": last.strip(),
                        "house": house,
                    }
                )
    except FileNotFoundError:
            sys.exit(f"Could not read {original_file}")


if __name__ == '__main__':
    main()
