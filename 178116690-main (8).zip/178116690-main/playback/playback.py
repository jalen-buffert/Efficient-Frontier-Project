n = input('Type something: ')

print(n.replace(' ','...'))
