import pytest
from convert import convert

def test_conversion():
    assert convert(1) == 149597870700
    assert convert(50) == 7479893535

def test_error():
    with pytest.raises(TypeError):
        convert("1")

def test_float_conversion():
    assert convert(0.001) == pytest.approx(14597870.691, abs=1e-2)
