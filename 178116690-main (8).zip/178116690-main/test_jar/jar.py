class Jar:
    def __init__(self, capacity=12):
        if not capacity > 0:
            raise ValueError("Jar can't be negative")
        self.capacity = capacity
        self.size = 0
        self.cookies = Jar.convert_cookies(self.size)

    def __str__(self):
        return self.cookies

    @classmethod
    def convert_cookies(cls, size1):
        return size1 * "🍪"

    def deposit(self, n):
        space = self.capacity - self.size
        if n > space:
            raise ValueError("No room for cookies")
        else:
            self.size += n
        return self.size

    def withdraw(self, n):
        if n > self.size:
            raise ValueError("Not enough cookies to take")
        else:
            self.size -= n
        return self.size

    @property
    def capacity(self):
        return self._capacity

    @capacity.setter
    def capacity(self, capacity):
        self._capacity = capacity

    @property
    def size(self):
        return self._size

    @size.setter
    def size(self, size):
        self._size = size
        self.cookies = Jar.convert_cookies(size)

    @property
    def cookies(self):
        return self._cookies

    @cookies.setter
    def cookies(self, cookies):
        self._cookies = cookies

def main():
    c = Jar(12)
    c.deposit(5)
    print(c)
    c.deposit(4)
    print(c)
    c.withdraw(3)
    print(c)

if __name__ == "__main__":
    main()
