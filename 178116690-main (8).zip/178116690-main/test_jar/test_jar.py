import pytest

from jar import Jar

def test_init():
    with pytest.raises(ValueError):
        Jar(-3)
        
def test_cor_init():
    jar = Jar(10)
    assert str(jar) == ''

def test_str():
    jar = Jar()
    assert str(jar) == ""
    jar.deposit(1)
    assert str(jar) == "🍪"
    jar.deposit(11)
    assert str(jar) == "🍪🍪🍪🍪🍪🍪🍪🍪🍪🍪🍪🍪"


def test_deposit():
    jar = Jar()
    assert jar.deposit(3) == 3


def test_withdraw():
    jar = Jar()
    jar.deposit(12)
    assert jar.withdraw(5) == 7

def test_bad_deposit():
    jar = Jar()
    jar.deposit(10)
    with pytest.raises(ValueError):
        jar.deposit(5)

def test_bad_withdraw():
    jar = Jar()
    jar.deposit(10)
    with pytest.raises(ValueError):
        jar.withdraw(11)
