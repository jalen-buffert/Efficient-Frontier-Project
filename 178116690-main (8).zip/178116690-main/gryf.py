students =["Hermione", "harry", "Ron"]

gryffindor = {student:"Gryffindor" for student in students}

print(gryffindor)


students = ["Hermione"]
