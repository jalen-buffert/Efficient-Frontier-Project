n = input("Input: ")
n = n

word = ""
for l in n:
    match l:
        case 'a' | 'e' | 'i' | 'o' | 'u' :
            word += ""
        case 'A' | 'E' | 'I' | 'O' | 'U':
            word += ""
        case _:
            word += l
print("Output: " + word)


