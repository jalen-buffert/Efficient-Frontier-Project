#Pseudo code -
# sep= seperator
# end= end the print
"""
Comments
"""

#Scope - a variable only existing in the context by which you define it
def main():
    name = input("What's your name? ")
    print(hello(name))

def hello(to="world"):
    return f"hello, {to}"

if __name__ == "__main__":
    main()


